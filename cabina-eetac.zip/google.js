/* Cabina EETAC · conexión con Google (Calendar, Drive, Gmail) y guardado en tu Drive.
   Todo ocurre en tu navegador: no hay servidor intermedio y nadie más ve tus datos. */
(function () {
  "use strict";
  const CID = (window.CABINA_CONFIG || {}).googleClientId || "";
  const SCOPES = [
    "openid", "email", "profile",
    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/drive.appdata"
  ].join(" ");
  const G = "https://www.googleapis.com";
  const ls = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
    del(k) { try { localStorage.removeItem(k); } catch (e) {} }
  };
  let tok = null;
  try { tok = JSON.parse(ls.get("cabina.tok")); } catch (e) {}
  let email = ls.get("cabina.email");
  const listeners = new Set();
  const notify = () => listeners.forEach(f => { try { f(); } catch (e) {} });
  const signedIn = () => !!(tok && tok.exp > Date.now());
  const configured = () => !!CID && !/^PEGA_AQUI/.test(CID);

  function loadGis() {
    return new Promise((ok, ko) => {
      if (window.google && google.accounts && google.accounts.oauth2) return ok();
      const s = document.createElement("script");
      s.src = "https://accounts.google.com/gsi/client"; s.async = true;
      s.onload = () => ok(); s.onerror = () => ko({ code: "gis_failed" });
      document.head.append(s);
    });
  }
  async function signIn() {
    if (!configured()) throw { code: "no_client", message: "Falta el ID de cliente de Google en config.js" };
    await loadGis();
    return new Promise((ok, ko) => {
      const tc = google.accounts.oauth2.initTokenClient({
        client_id: CID, scope: SCOPES, hint: email || undefined,
        callback: async r => {
          if (r.error) { ko({ code: r.error, message: r.error_description || r.error }); return; }
          tok = { t: r.access_token, exp: Date.now() + (Number(r.expires_in || 3600) - 60) * 1000 };
          ls.set("cabina.tok", JSON.stringify(tok));
          try { const u = await api(G + "/oauth2/v3/userinfo"); email = u.email; ls.set("cabina.email", email); } catch (e) {}
          await loadRemote();
          notify(); ok();
        },
        error_callback: e => ko({ code: e && e.type || "popup_closed", message: "No se completó el inicio de sesión" })
      });
      tc.requestAccessToken({ prompt: email ? "" : "consent" });
    });
  }
  function signOut() {
    try { if (tok && window.google && google.accounts) google.accounts.oauth2.revoke(tok.t, () => {}); } catch (e) {}
    tok = null; ls.del("cabina.tok"); notify();
  }
  async function api(url, opt) {
    opt = opt || {};
    if (!signedIn()) throw { code: "signin", message: "Inicia sesión con Google" };
    const r = await fetch(url, Object.assign({}, opt, { headers: Object.assign({ Authorization: "Bearer " + tok.t }, opt.headers || {}) }));
    if (r.status === 401) { tok = null; ls.del("cabina.tok"); notify(); throw { code: "needs_reauth" }; }
    if (r.status === 403) { throw { code: "forbidden", message: await r.text() }; }
    if (r.status === 429) { throw { code: "rate_limited", retryable: true }; }
    if (!r.ok) throw { code: "upstream_error", message: await r.text(), retryable: r.status >= 500 };
    const ct = r.headers.get("content-type") || "";
    return ct.includes("json") ? r.json() : r.text();
  }
  async function pmap(arr, n, fn) {
    const out = new Array(arr.length); let i = 0;
    await Promise.all(Array.from({ length: Math.min(n, arr.length) }, async () => { while (i < arr.length) { const k = i++; out[k] = await fn(arr[k]); } }));
    return out;
  }
  const driveQ = q => q.replace(/parentId\s*=\s*'([^']+)'/g, "'$1' in parents").replace(/title contains/g, "name contains").replace(/owner\s*=\s*'me'/g, "'me' in owners");

  /* --- herramientas con la misma forma que usa la app --- */
  const tools = {
    "Google Calendar": {
      async list_calendars() {
        const r = await api(G + "/calendar/v3/users/me/calendarList?maxResults=50");
        return { calendars: (r.items || []).filter(c => c.selected !== false).map(c => ({ id: c.id, summary: c.summary })) };
      },
      async list_events(i) {
        const p = new URLSearchParams({ timeMin: new Date(i.startTime).toISOString(), timeMax: new Date(i.endTime).toISOString(), singleEvents: "true", orderBy: "startTime", maxResults: String(i.pageSize || 250) });
        const r = await api(G + "/calendar/v3/calendars/" + encodeURIComponent(i.calendarId) + "/events?" + p);
        return { items: r.items || [] };
      }
    },
    "Google Drive": {
      async search_files(i) {
        const p = new URLSearchParams({ q: driveQ(i.query || ""), pageSize: String(i.pageSize || 25), fields: "files(id,name,mimeType,webViewLink,modifiedTime,createdTime)", supportsAllDrives: "true", includeItemsFromAllDrives: "true" });
        if (i.orderBy && !/fullText/.test(i.query || "")) p.set("orderBy", i.orderBy);
        const r = await api(G + "/drive/v3/files?" + p);
        return { files: (r.files || []).map(f => ({ id: f.id, title: f.name, mimeType: f.mimeType, viewUrl: f.webViewLink, modifiedTime: f.modifiedTime, createdTime: f.createdTime })) };
      }
    },
    "Gmail": {
      async search_threads(i) {
        const q = i.query || "";
        const p = new URLSearchParams({ q, maxResults: String(Math.min(i.pageSize || 20, 25)) });
        if (/in:spam/.test(q)) p.set("includeSpamTrash", "true");
        const r = await api(G + "/gmail/v1/users/me/threads?" + p);
        const threads = await pmap(r.threads || [], 6, async t => {
          const d = await api(G + "/gmail/v1/users/me/threads/" + t.id + "?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=To");
          const m = (d.messages || []).slice(-1)[0] || {};
          const hs = (m.payload && m.payload.headers) || [];
          const h = n => (hs.find(x => x.name.toLowerCase() === n) || {}).value || "";
          const from = h("from"); const mm = from.match(/^(.*?)\s*<([^>]+)>/);
          const addr = mm ? mm[2] : from; const name = mm ? mm[1].replace(/^"|"$/g, "") : "";
          const url = "https://mail.google.com/mail/?authuser=" + encodeURIComponent(email || "") + "#all/" + t.id;
          return { id: t.id, viewUrl: url, messages: [{ sender: addr, subject: h("subject"), snippet: m.snippet || "", date: new Date(Number(m.internalDate || Date.now())).toISOString(), labelIds: m.labelIds || [], toRecipients: h("to").split(",").filter(Boolean), addressDisplayNames: name ? [{ emailAddress: addr, displayName: name }] : [], viewUrl: url }] };
        });
        return { threads };
      }
    }
  };
  const mcp = {
    async callTool(server, tool, input) {
      const f = tools[server] && tools[server][tool];
      if (!f) throw { code: "not_in_manifest" };
      try { return { payload: await f(input || {}) }; }
      catch (e) { throw (e && e.code) ? e : { code: "upstream_error", message: String(e) }; }
    },
    watchTool(server, tool, input, handler, opts) {
      opts = opts || {}; let alive = true;
      const run = async () => {
        if (!alive) return;
        try { const r = await mcp.callTool(server, tool, input); if (alive) handler({ type: "data", result: r }); }
        catch (e) { if (alive) handler({ type: "error", error: e }); }
      };
      run();
      const iv = opts.refetchInterval ? setInterval(() => { if (!document.hidden) run(); }, Math.max(60000, opts.refetchInterval)) : null;
      listeners.add(run);
      return () => { alive = false; if (iv) clearInterval(iv); listeners.delete(run); };
    },
    async invalidate() {}
  };

  /* --- guardado: tu navegador + un archivo privado de la app en tu Drive --- */
  const FILE = "cabina-datos.json";
  const store = { docs: {}, fileId: null, subs: new Map(), timer: null };
  try { store.docs = JSON.parse(ls.get("cabina.docs") || "{}"); } catch (e) {}
  const key = p => p.replace(/^data\/users\/[^/]+\//, "");
  const snap = (id, d, pending) => ({ id, exists: !!d, data: () => d ? JSON.parse(JSON.stringify(d.v)) : undefined, metadata: { fromCache: false, hasPendingWrites: !!pending } });
  function emit(k) { const d = store.docs[k]; (store.subs.get(k) || []).forEach(f => { try { f(snap(k, d)); } catch (e) {} }); }
  async function loadRemote() {
    if (!signedIn()) return;
    try {
      const r = await api(G + "/drive/v3/files?spaces=appDataFolder&fields=files(id,name)&q=" + encodeURIComponent("name='" + FILE + "'"));
      const f = (r.files || [])[0];
      if (f) {
        store.fileId = f.id;
        let data = await api(G + "/drive/v3/files/" + f.id + "?alt=media");
        if (typeof data === "string") data = JSON.parse(data || "{}");
        const remote = (data && data.docs) || {};
        let changedLocal = false;
        for (const [k, d] of Object.entries(remote)) { if (!store.docs[k] || (d.ts || 0) > (store.docs[k].ts || 0)) { store.docs[k] = d; emit(k); } }
        for (const [k, d] of Object.entries(store.docs)) { if (!remote[k] || (d.ts || 0) > (remote[k].ts || 0)) changedLocal = true; }
        ls.set("cabina.docs", JSON.stringify(store.docs));
        if (changedLocal) upload();
      } else upload();
    } catch (e) {}
  }
  function upload() {
    clearTimeout(store.timer);
    store.timer = setTimeout(async () => {
      if (!signedIn()) return;
      const body = JSON.stringify({ docs: store.docs, savedAt: new Date().toISOString() });
      try {
        if (store.fileId) {
          await api("https://www.googleapis.com/upload/drive/v3/files/" + store.fileId + "?uploadType=media", { method: "PATCH", headers: { "Content-Type": "application/json" }, body });
        } else {
          const b = "cabina" + Date.now();
          const meta = JSON.stringify({ name: FILE, parents: ["appDataFolder"] });
          const multipart = `--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--${b}\r\nContent-Type: application/json\r\n\r\n${body}\r\n--${b}--`;
          const r = await api("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id", { method: "POST", headers: { "Content-Type": "multipart/related; boundary=" + b }, body: multipart });
          store.fileId = r.id;
        }
      } catch (e) {}
    }, 1500);
  }
  function docRef(path) {
    const k = key(path);
    return {
      id: k, path,
      async get() { return snap(k, store.docs[k]); },
      async set(v) { store.docs[k] = { v: JSON.parse(JSON.stringify(v)), ts: Date.now() }; ls.set("cabina.docs", JSON.stringify(store.docs)); upload(); },
      async update(v) { const cur = store.docs[k] ? store.docs[k].v : {}; return this.set(Object.assign({}, cur, v)); },
      async delete() { delete store.docs[k]; ls.set("cabina.docs", JSON.stringify(store.docs)); upload(); },
      onSnapshot(next) { const arr = store.subs.get(k) || []; arr.push(next); store.subs.set(k, arr); setTimeout(() => next(snap(k, store.docs[k])), 0); return () => store.subs.set(k, (store.subs.get(k) || []).filter(f => f !== next)); }
    };
  }
  const db = { doc: docRef, collection: p => ({ doc: id => docRef(p + "/" + id) }) };
  const user = { id: async () => "me", isOwner: () => true, canEdit: () => true, can: () => true };
  const downloads = {
    async save({ filename, data }) {
      const blob = data instanceof Blob ? data : new Blob([data], { type: /\.html$/.test(filename) ? "text/html" : /\.json$/.test(filename) ? "application/json" : "application/octet-stream" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = filename; document.body.append(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      return { status: "saved" };
    }
  };
  const caps = { mcp, db, user, downloads };
  window.claude = { use: async n => caps[n] || null };
  window.cabinaAuth = { signIn, signOut, signedIn, configured, email: () => email, onChange: f => listeners.add(f), sync: loadRemote, store: () => store.docs };
  if (signedIn()) loadRemote();
})();
