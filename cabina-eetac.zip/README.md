# Cabina EETAC

Web para organizar el curso en la EETAC: horario, notas y lo que necesitas para aprobar, apuntes con esquema visual, correo de profesores, Drive y vuelos de estudio. Se instala en el móvil, la tablet y el ordenador.

No necesita servidor ni base de datos: entras con tu cuenta de Google y tus datos se guardan en una carpeta privada de la app dentro de tu propio Drive.

## Puesta en marcha (una sola vez)

### 1 · GitHub
1. Crea una cuenta en https://github.com (gratis).
2. Botón **+ → New repository**. Nombre: `cabina-eetac`. Puede ser **Private**. Pulsa **Create repository**.
3. En la página del repositorio, pulsa **uploading an existing file**, arrastra **todos los archivos de esta carpeta** y pulsa **Commit changes**.
   - No subas `mis-datos.json`: ese archivo lleva tus notas y se carga desde la propia web.

### 2 · Vercel
1. Entra en https://vercel.com y regístrate con **Continue with GitHub**.
2. **Add New → Project**, elige `cabina-eetac` y pulsa **Import**.
3. En *Framework Preset* deja **Other**, no toques nada más y pulsa **Deploy**.
4. Copia la dirección que te da (algo como `https://cabina-eetac.vercel.app`).

### 3 · Google Cloud (para entrar con tu correo)
1. Entra en https://console.cloud.google.com. Si con la cuenta de la UPC no te deja crear proyectos, usa tu Gmail personal: solo sirve para crear la "llave"; después entrarás en la web con la cuenta que quieras.
2. Crea un proyecto llamado **Cabina EETAC**.
3. **APIs y servicios → Biblioteca**: activa **Google Calendar API**, **Google Drive API** y **Gmail API**.
4. **Google Auth Platform** (o *Pantalla de consentimiento de OAuth*):
   - **Branding**: nombre *Cabina EETAC* y tu correo.
   - **Audience / Público**: tipo **External** y deja la app en **Testing**. En **Test users** añade tu correo de la UPC (y el de cada amigo que la vaya a usar, hasta 100).
5. **Clients / Credenciales → Crear cliente → Aplicación web**:
   - En **Orígenes de JavaScript autorizados** pon la dirección de Vercel del paso 2 (sin barra al final).
   - Pulsa **Crear** y copia el **ID de cliente** (termina en `.apps.googleusercontent.com`).

### 4 · Pegar el ID en la web
1. En GitHub, abre `config.js`, pulsa el lápiz ✏️ y sustituye `PEGA_AQUI_TU_ID_DE_CLIENTE.apps.googleusercontent.com` por tu ID.
2. **Commit changes**. Vercel publica la nueva versión solo, en un minuto.

### 5 · Primer uso
1. Abre tu dirección de Vercel y pulsa **Entrar con Google**.
2. Google avisará de que la app no está verificada (es normal, es tuya): **Configuración avanzada → Ir a Cabina EETAC** y acepta los permisos.
3. En **Ajustes ⚙ → Cargar archivo .json** elige `mis-datos.json`. Desde ese momento tus datos viajan contigo a cualquier dispositivo.

### 6 · Instalarla como app
- **iPhone / iPad (Safari):** Compartir → Añadir a pantalla de inicio.
- **Android (Chrome):** menú ⋮ → Instalar aplicación.
- **Ordenador (Chrome o Edge):** icono de instalar en la barra de direcciones, o menú ⋮ → Guardar y compartir → Instalar.
- **Mac (Safari):** Archivo → Añadir al Dock.

## Para tus amigos
Añade su correo en *Test users* (paso 3.4) y pásales la dirección. Al entrar, pulsan **Usar plantilla AT11** (horario de clase y exámenes, sin notas) o cargan su propio `.json`. Cada uno ve solo su correo, su Drive y sus datos.

## Cambiar algo
Edita el archivo en GitHub y haz *Commit*: Vercel lo publica solo. Tus datos no se pierden, porque están en tu Drive, no en el código.
