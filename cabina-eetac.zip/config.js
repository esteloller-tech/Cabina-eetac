// Cabina EETAC · configuración
// Pega aquí el "ID de cliente" de Google que crearás en Google Cloud (termina en .apps.googleusercontent.com).
window.CABINA_CONFIG = {
  googleClientId: "PEGA_AQUI_TU_ID_DE_CLIENTE.apps.googleusercontent.com"
};
